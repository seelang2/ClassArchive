TestHelpers.droppable = {
	shouldDrop: function() {
		// todo: actually implement this
		ok(true, "missing test - untested code is broken code");
	},
	shouldNotDrop: function() {
		// todo: actually implement this
		ok(true, "missing test - untested code is broken code");
	}
};