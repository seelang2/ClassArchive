// The following lines can be copied and pasted into the console to add jQuery support
// (or load any other script, for that matter)
var s = document.createElement('SCRIPT');
s.src = 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js';
document.body.appendChild(s);

/**/
var s = document.createElement('SCRIPT');s.src = 'testapp1.js';document.body.appendChild(s);
