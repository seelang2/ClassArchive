function getOrdinal(num) {
	
	// 'st': number ends in 1 but not 11
	// 'nd': number ends in 2 but not 12
	// 'rd': number ends in 3 but not 13
	// 'th': all other numbers
	
	switch(true) {
		case num % 10 == 1 && num % 100 != 11:
			var ordinal = 'st';
		break;
	
		case num % 10 == 2 && num % 100 != 12:
			var ordinal = 'nd';
		break;
	
		case num % 10 == 3 && num % 100 != 13:
			var ordinal = 'rd';
		break;
		
		default:
			var ordinal = 'th';
		break;
	}
	
	return ordinal; 
}


