<?php
// set CORS header to allow all access
header('Access-Control-Allow-Origin: *');
echo file_get_contents('contact1.json');