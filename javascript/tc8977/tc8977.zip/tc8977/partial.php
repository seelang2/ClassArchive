<?php
// set CORS policy to allow all domains to access this
// ref: https://developer.mozilla.org/en-US/docs/Web/HTTP/Access_control_CORS
header('Access-Control-Allow-Origin: *');

?>
<h1>Fusce blandit vitae lacus at accumsan</h1>
<p>
Fusce blandit vitae lacus at accumsan. Sed euismod aliquet leo, eu hendrerit neque iaculis et. Nam cursus magna vitae metus tincidunt placerat. Nullam non gravida ipsum. Aenean iaculis, neque eu vestibulum hendrerit, nulla massa dictum dui, at accumsan ex ante ut odio. Nullam maximus, orci non congue molestie, orci mauris tempus odio, vitae malesuada arcu est eu massa. Nullam id blandit justo, sit amet ornare ipsum. Nulla cursus eu odio nec cursus. Proin placerat volutpat ipsum quis hendrerit. Integer quis purus ut magna luctus euismod quis non urna. Aenean pharetra tortor non massa faucibus ornare.
</p>
<p>
Pellentesque in condimentum neque. Sed quis dui nec dui lobortis hendrerit non quis magna. Nulla elit mi, pulvinar sodales venenatis nec, tempor nec leo. Quisque vehicula dictum orci ut euismod. Integer massa nunc, venenatis ut odio eu, pulvinar ullamcorper lorem. Maecenas eget pretium sem. Nam sed pellentesque lacus. Morbi elementum nulla interdum, tristique massa rutrum, imperdiet turpis.
</p>
