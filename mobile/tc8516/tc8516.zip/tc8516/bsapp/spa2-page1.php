<?php
// set CORS header to allow all access
header('Access-Control-Allow-Origin: *');
?>
		<div id="page1" data-role="view">
			<h2>Page 1</h2>
			<p>
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas aliquet ligula in mi tristique, vel hendrerit dolor volutpat. Quisque gravida quam sit amet dolor volutpat, vitae vulputate mi vulputate. Vestibulum ut tortor imperdiet eros imperdiet blandit quis at lacus. Suspendisse volutpat eros vel quam vehicula malesuada. Curabitur diam odio, euismod vel ipsum sed, euismod placerat arcu. Nunc dictum sagittis sagittis. Pellentesque sed nibh ex.
			</p>
			<p>
			Donec a massa sed magna porttitor euismod nec a orci. Vestibulum ultricies pellentesque ante, nec porttitor eros suscipit sit amet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam ut commodo magna. Integer et elementum turpis. Nullam maximus tincidunt orci, eu ornare metus sodales quis. Donec quis mi laoreet dolor ullamcorper pretium at sed ante. Suspendisse nec luctus velit, ac tincidunt est. Nullam maximus nunc id est rhoncus venenatis. Fusce interdum velit vitae leo egestas tempor. Mauris scelerisque, enim vitae fringilla tristique, arcu turpis faucibus erat, ut laoreet nibh elit sed lacus. Integer ut facilisis tellus, at pulvinar nisi. Etiam cursus odio sed risus pharetra, vel lobortis enim finibus.
			</p>
		</div>
