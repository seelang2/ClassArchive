<?php
// set CORS header to allow all access
header('Access-Control-Allow-Origin: *');
?>
		<div id="page2" data-role="view">
			<h2>Page 2</h2>
			<p>
			Aenean ultrices, arcu ullamcorper rutrum congue, felis leo rutrum tortor, at pulvinar leo neque eu nulla. Nam a felis condimentum, consequat ex vitae, tempor mi. In feugiat pulvinar dolor, id posuere nisl fermentum ac. Praesent non augue enim. Nullam luctus, libero vehicula porttitor hendrerit, augue risus imperdiet diam, a elementum augue enim non dui. Integer sit amet faucibus ante, sit amet consequat turpis. Sed cursus tincidunt odio, at dapibus nunc blandit non. Phasellus nec interdum diam. In vitae tempor nulla, eu condimentum massa. In finibus commodo est eu varius. Nullam placerat dolor vitae purus rhoncus, at facilisis ex varius. Proin semper commodo dapibus. Proin justo est, pretium a orci sit amet, consectetur convallis neque. Vestibulum nec tempor elit. Duis varius, ante venenatis viverra venenatis, sem purus suscipit nunc, a lobortis lorem turpis ac lectus. Cras nulla diam, pellentesque eget pretium nec, viverra eu velit.
			</p>
			<p>
			Duis feugiat urna ut laoreet iaculis. Etiam in mi porta, imperdiet nunc id, commodo orci. Vestibulum eu purus id est euismod tincidunt non ut arcu. Ut rutrum sit amet ipsum et sodales. Nulla facilisi. Duis nibh orci, dignissim vel semper in, hendrerit nec dui. Integer finibus, risus fringilla mattis posuere, nulla nisi faucibus turpis, ut ullamcorper nunc neque et lectus. In cursus nisl mi, eget luctus quam pretium non. Etiam in turpis est. Donec rutrum eros quis urna rhoncus, eu dapibus tortor luctus. Sed lectus ex, placerat ut lorem quis, porta mollis nisl. Nullam at libero in mi condimentum egestas at molestie purus. Sed sapien nibh, sagittis nec mattis vel, pharetra et nisl.
			</p>
		</div>
