/*

*/
(function(App) {
	
	//App.newMethod = function() { };

	//$(App).on('app.start', App.newMethod);

})(window.App = window.App || {});