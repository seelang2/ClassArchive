<?php
// set CORS header to allow all access
header('Access-Control-Allow-Origin: *');
?>
		<div id="page3" data-role="view">
			<h2>Page 3</h2>
			<p>
			Nam lacinia lobortis lectus, commodo mattis ipsum molestie quis. Nam mollis metus nec mollis consequat. Sed non est lorem. Aliquam in volutpat lacus. Maecenas felis nulla, molestie sed aliquam a, blandit ut turpis. Ut eu maximus leo, ut viverra mi. Donec pretium enim a lacus viverra fringilla.
			</p>
			<p>
			Vestibulum maximus dui sit amet nisi interdum, nec euismod nulla egestas. Donec tincidunt efficitur viverra. Donec placerat risus at erat fringilla, vel interdum velit condimentum. Morbi elit dolor, dapibus at sem eu, imperdiet imperdiet nulla. Sed a egestas libero. Nullam sit amet urna quis ex sodales lobortis in nec tellus. In a justo dignissim, mollis ligula quis, consectetur urna. Praesent iaculis nibh sed magna pulvinar tempor. Pellentesque tincidunt convallis efficitur. Nulla bibendum at enim ac tincidunt.
			</p>
		</div>
