<?php 
echo '<h3>$_GET:</h3>';
echo '<pre>'.print_r($_GET,true).'</pre>';

echo '<h3>$_POST:</h3>';
echo '<pre>'.print_r($_POST,true).'</pre>';

echo '<h3>$_REQUEST:</h3>';
echo '<pre>'.print_r($_REQUEST,true).'</pre>';

echo '<h3>$_SERVER:</h3>';
echo '<pre>'.print_r($_SERVER,true).'</pre>';


