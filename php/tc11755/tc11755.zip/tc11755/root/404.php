<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>404 - File Not Found</title>

	<style type="text/css">
	</style>
</head>
<body>

<div style="font-weight:bold;font-size:400%;text-align:center;">
	No Soup For You.
</div>

</body>
</html>