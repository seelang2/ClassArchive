	</div>
	<div id="pagefooter">
		<p>Copyright &copy; <?php echo date('Y'); ?> Creative Commons.</p>
	</div>
</div>

</body>
</html>