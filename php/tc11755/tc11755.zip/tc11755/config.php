<?php


// Database settings
@define('DB_HOST','localhost');
@define('DB_NAME','tc11755');
@define('DB_USER','root');
@define('DB_PASSWORD','');


