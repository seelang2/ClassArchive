<?php
/**
 * Configuration file
 */

// database parameters
@define('DB_NAME', 'tc12196');
@define('DB_HOST', 'localhost');
@define('DB_USER', 'root');
@define('DB_PASSWORD', '');


