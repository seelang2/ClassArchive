<?php

for ($c = 0; $c < 10; $c++) {
	echo $c;
}

$c = 0;
while ($c < 10) {
	echo $c;
	$c++;
}

$c = 0;
do {
	echo $c;
	$c++
} while ($c < 10);
