<?php
/**
 * Application initialization
 */

session_start(); // initialize sessions

// load other modules
require('config.php');
require('database.php');
