			<!-- end content -->
		</div>
		<div id="pagefooter">
			<p>Creative Commons Open License &copy<?php echo date('Y'); ?>. Use at your own risk.</p>
		</div>
	</div><!-- #wrapper -->
</body>
</html>