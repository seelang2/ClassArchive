<?php
include ('header.php');
?>

<h1>Products Page</h1>

<p>blah blah blah</p>

<?php include ('footer.php'); ?>