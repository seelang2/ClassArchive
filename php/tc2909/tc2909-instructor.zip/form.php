
<h1>Form data handler demo</h1>


<form action="target.php" method="post">
	<p>First Name: <input name="firstname" /></p>
    <p>Last Name: <input name="lastname" /></p>
    <p><input type="submit" /></p>
</form>

