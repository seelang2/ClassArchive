    </div><!-- content -->
    <div id="footer">
    	Copyright &copy; <?php echo date('Y'); ?> Your Company Here.
    </div><!-- footer -->
</div><!-- wrapper -->



</body>
</html>