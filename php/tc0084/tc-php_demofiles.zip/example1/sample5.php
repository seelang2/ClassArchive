<?php

require_once("config.php");
include("header2.php"); // include header file
?>

<h2>Pulling it all together</h2>
<p>This demo shows how a backend administration panel for a content management system may operate.</p>

<?php
include("footer.php"); // include footer file
?>