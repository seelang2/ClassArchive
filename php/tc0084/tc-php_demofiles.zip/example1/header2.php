

<script type="text/javascript">
function del_confirm() {
	return confirm("Do you really wish to delete this item permanently?");
}
</script>



<h1>Demo: <?php echo $me; ?></h1>
<div id="menu">
<a href="sample5.php">Home</a>&nbsp;|
<a href="sample5a.php">Manage Users</a>&nbsp;|
<a href="sample5b.php">Manage Classes</a>&nbsp;|
<a href="sample5c.php">Manage Class Recordings</a>&nbsp;
</div>
<hr noshade />
<p>&nbsp;</p>