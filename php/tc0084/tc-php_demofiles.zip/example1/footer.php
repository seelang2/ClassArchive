<p>&nbsp;</p>
<hr noshade />
<div id="footer">
<p>View Demo:&nbsp;
<a href="sample1.php">Sample1</a>&nbsp;|
<a href="sample2.php">Sample2</a>&nbsp;|
<a href="sample3.php">Sample3</a>&nbsp;|
<a href="sample4.php">Sample4</a>&nbsp;|
<a href="sample5.php">Sample5</a>&nbsp;
</p>
<p><em>Sample code by Chris Langtiw Feb/2007. Feel free to examine and use the code as you wish.</em></p>
</div>
