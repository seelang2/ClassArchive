<?php

require_once("config.php");

$tablename = "user_info";


if (isset($_GET['mode']) && $_GET['mode'] != "") $mode = strtoupper($_GET['mode']); else $mode = "";

if (isset($_GET['id']) && $_GET['id'] != "") $id = $_GET['id']; else $id = "";


include("header.php"); // include header file

?>

<script type="text/javascript">
function del_confirm() {
	return confirm("Do you really wish to delete this item permanently?");
}
</script>

<?php

switch ($mode)
{
	case 'ADD':

		$sql = "INSERT INTO $tablename SET ";
	
		$c = count($_POST) - 1; // get count of form items and subtract one (for submit button)
		reset($_POST); // set array pointer to beginning of array for re-reading
		$i = 0;
		while (list($key, $val) = each($_POST)) {
			if ($key != "butSubmit") { // avoid submit button field
				if ($val != "") {
					$val = escape($val);
					if ($i > 0) $sql .= ", ";      
					$sql .= "$key = '$val'";
				}
				$i++;
		   }
		} // close while
	
		if (@mysql_query($sql)) {
		  echo '<p>The database was updated successfully.</p>';
		} else {
		  echo '<p>Error encountered during submission: ' . mysql_error() . '</p>';
		}

		echo "<p>Query used: $sql</p>";
	break;
	case 'ADDFORM':

		$field_labels = $table_field_labels[$tablename];

		?>
		<form action="<?php echo $me; ?>?mode=add" method="post">
		<table>
		<?php
		while (list($field, $label) = each($field_labels)) {
			if ($label != "") echo "<tr><td align=\"right\">$label:&nbsp;</td><td><input type=\"text\" name=\"$field\" value=\"\" size=\"25\" maxlength=\"100\" /></td></tr>";
		}
		?>
		<tr><td colspan="2" align="center"><input type="submit" name="butSubmit" value="Add Record" /></td></tr>
		</table>
		
		</form>
		<?php	

	break;
	case 'EDIT':
		$idfield = 'id';

		$sql = "UPDATE $tablename SET ";
	
		$c = count($_POST) - 1; // get count of form items and subtract one (for submit button)
		reset($_POST); // set array pointer to beginning of array for re-reading
		$i = 0;
		while (list($key, $val) = each($_POST)) {
			if ($key != "butSubmit") { // avoid submit button field
				if ($val != "") {
					$val = escape($val);
					if ($i > 0) $sql .= ", ";      
					$sql .= "$key = '$val'";
				}
				$i++;
		   }
		} // close while
		
		$sql .= " WHERE $idfield = $id";
	
		if (@mysql_query($sql)) {
		  echo '<p>The database was updated successfully.</p>';
		} else {
		  echo '<p>Error encountered during update: ' . mysql_error() . '</p>';
		}

		echo "<p>Query used: $sql</p>";
	break;
	case 'EDITFORM':

		$field_labels = $table_field_labels[$tablename];
	
		$sql = "SELECT * FROM $tablename WHERE id = '$id'";
		$results = @mysql_query($sql);
		if (!$results) exit('<p>Error performing query: ' . mysql_error() . '</p>');
	
		$row = mysql_fetch_array($results);

		?>
		<form action="<?php echo $me; ?>?mode=edit&id=<?php echo $id; ?>" method="post">
		<table>
		<?php
		while (list($field, $label) = each($field_labels)) {
			if ($label != "") echo "<tr><td align=\"right\">$label:&nbsp;</td><td><input type=\"text\" name=\"$field\" value=\"" . $row[$field] . "\" size=\"25\" maxlength=\"100\" /></td></tr>";
		}
		?>
		<tr><td colspan="2" align="center"><input type="submit" name="butSubmit" value="Update Record" /></td></tr>
		</table>
		
		</form>
		<?php	

	break;
	case 'DELETE':
		$idfield = 'id';
		
		$sql = "DELETE FROM $tablename WHERE $idfield = $id";

		if (@mysql_query($sql)) {
		  echo '<p>The database record was successfully deleted.</p>';
		} else {
		  echo '<p>Error encountered during deletion: ' . mysql_error() . '</p>';
		}

		echo "<p>Query used: $sql</p>";
	break;
	case 'LIST':
	
		// build query
		$sql = "SELECT * FROM $tablename";
	
		// submit query
		$results = @mysql_query($sql);
		if (!$results) exit('<p>Error performing query: ' . mysql_error() . '</p>');
		
		
		echo "<table border=\"1\" cellpadding=\"5\" cellspacing=\"0\">";
		echo "<tr><td>First Name</td><td>Last Name</td><td>Date Joined</td><td>Email Address</td><td>Functions</td></tr>";
		
		// display results
		while ($row = mysql_fetch_array($results)) {
		
		echo "<tr><td>" . $row['firstname'] . "</td><td>" . $row['lastname'] . "</td><td>" . $row['date_joined'] . "</td><td>" . $row['email'] . "</td><td><a href=\"$me?mode=editform&id=" . $row['id'] . "\">EDIT</a>&nbsp;&nbsp;<a href=\"$me?mode=delete&id=" . $row['id'] . "\" onclick=\"javascript: return del_confirm();\">DELETE</a></td></tr>";
		
		}
		
		echo "</table>";
	
		echo "<p><a href=\"$me?mode=addform\">Add new record</a></p>";
	break;
	default:
?>
<p>Demo: Dynamic forms and submission demo using static table (user_info) and deletion confirmation using JavaScript.</p>
<p>Please select an operation from the menu above.</p>

<?php
	break;
}

include("footer.php"); // include footer file
?>