<h1>Demo: <?php echo $me; ?></h1>
<div id="menu">
<a href="<?php echo $me; ?>">Home</a>&nbsp;|
<a href="<?php echo $me; ?>?mode=addform">Add New Record</a>&nbsp;|
<a href="<?php echo $me; ?>?mode=list">List Records</a>&nbsp;
</div>
<hr noshade />
<p>&nbsp;</p>