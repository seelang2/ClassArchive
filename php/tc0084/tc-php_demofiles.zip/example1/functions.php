<?php
/*
functions.php - Function include file

Used in modular/reusable code demo.

*/

// ====================================================================
//	Format a string correctly for safe insert under all PHP conditions
//  Used on any string intended for database insertion
//	Parameters:
//		$str 	- String to reformat
function escape($str)
{
	return mysql_real_escape_string(stripslashes($str));				
}


// ====================================================================
//	Delete a record from a given table
//	Parameters:
//		$tablename 	- Name of table
//		$id			- Record ID value
//		$idfield	- (optional) Name of ID field (defaults to 'id')
//		$showquery	- (optional) Show SQL query used
function db_delete($tablename, $id, $idfield = 'id', $showquery = FALSE)
{
	$sql = "DELETE FROM $tablename WHERE $idfield = $id";

	if (@mysql_query($sql)) {
	  echo '<p>The database record was successfully deleted.</p>';
	} else {
	  echo '<p>Error encountered during deletion: ' . mysql_error() . '</p>';
	}

	if ($showquery) echo "<p>Query used: $sql</p>";
	return;
}


// ====================================================================
//	Lists all records from a given table
//	Parameters:
//		$tablename 		- Name of table
//		$field_labels	- Array of field labels
//		$idfield		- (optional) Name of ID field (defaults to 'id')
//		$query			- (optional) Custom query (overrides $sql value)
function db_list($tablename, $field_labels, $idfield = 'id', $query = NULL)
{
	// build query
	if (!is_null($query)) $sql = $query; else $sql = "SELECT * FROM $tablename";

	// submit query
	$results = @mysql_query($sql);
	if (!$results) exit('<p>Error performing query: ' . mysql_error() . '</p>');
	
	echo "<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\">\n";

	// create table header row
	echo "<tr>";
	while (list($field, $label) = each($field_labels)) {
		if ($label != "") 
			echo "<td>" . $label . "</td>";
	}
	echo "<td>Options</td>";
	echo "</tr>\n";
	reset($field_labels); // move pointer back to start of array
	
	// display results
	while ($row = mysql_fetch_array($results)) {
		echo "<tr>";
		while (list($field, $label) = each($field_labels)) {
			if ($label != "")
				echo "<td>" . $row[$field] . "</td>";
		}
		// add function options to end
		echo "<td><a href=\"$me?mode=editform&id=" . $row[$idfield] . "\">EDIT</a>&nbsp;&nbsp;<a href=\"$me?mode=delete&id=" . $row[$idfield] . "\" onclick=\"javascript: return del_confirm();\">DELETE</a></td>";

		echo "</tr>\n";
		reset($field_labels);
	}
	echo "</table>";
	return;
}


// ====================================================================
//	Multipurpose Add/Edit form
//	Parameters:
//		$mode			- ADD or DELETE
//		$tablename 		- Name of table
//		$field_labels	- Array of field labels
//		$target			- Form action target (including any GET parameters)
//		$id				- (optional)Record ID value (if EDIT)
//		$idfield		- (optional) Name of ID field (defaults to 'id') (IF EDIT)
//		$showquery		- (optional) Show SQL query used
function db_mpform($mode, $tablename, $field_labels, $target, $id = NULL, $idfield = 'id', $showquery = FALSE)
{
	$mode = strtoupper($mode);
	if ($mode != "ADD" && $mode != "EDIT") exit("Error: Invalid Mode $mode in db_mpform");
	if ($mode == "EDIT") {
		$sql = "SELECT * FROM $tablename WHERE id = '$id'";
		$results = @mysql_query($sql);
		if (!$results) exit('<p>Error performing query: ' . mysql_error() . '</p>');
		$row = mysql_fetch_array($results);
	}

	echo "<form action=\"$target\" method=\"post\">";
	echo "<table>\n";

	while (list($field, $label) = each($field_labels)) {
		if ($label != "") {
			echo "<tr><td align=\"right\">$label:&nbsp;</td><td><input type=\"text\" name=\"$field\" value=\"";
			if ($mode == "EDIT") echo $row[$field]; 
			echo "\" size=\"25\" maxlength=\"100\" /></td></tr>\n";
		}
	}
	echo "<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"butSubmit\" value=\"Update Record\" /></td></tr>";
	echo "</table></form>\n";

	if ($showquery) echo "<p>Query used: $sql</p>";
	return;
}


// ====================================================================
//	Multipurpose Add/Edit form update
//	Parameters:
//		$mode		- ADD or DELETE
//		$tablename 	- Name of table
//		$id			- (optional)Record ID value (if EDIT)
//		$idfield	- (optional) Name of ID field (defaults to 'id') (IF EDIT)
//		$showquery	- (optional) Show SQL query used
function db_mpform_update($mode, $tablename, $id = NULL, $idfield = 'id', $showquery = FALSE)
{
	$mode = strtoupper($mode);
	if ($mode != "ADD" && $mode != "EDIT") exit("Error: Invalid Mode $mode in db_mpform_update");

	if ($mode == "ADD") {
		$sql = "INSERT INTO ";
	} else {
		$sql = "UPDATE ";
	}

	$sql .= "$tablename SET ";

	$c = count($_POST) - 1; // get count of form items and subtract one (for submit button)
	reset($_POST); // set array pointer to beginning of array for re-reading
	$i = 0;
	while (list($key, $val) = each($_POST)) {
		if ($key != "butSubmit") { // avoid submit button field
			if ($val != "") {
				$val = escape($val);
				if ($i > 0) $sql .= ", ";      
				$sql .= "$key = '$val'";
			}
			$i++;
	   }
	} // close while
	
	if ($mode == "EDIT") $sql .= " WHERE $idfield = $id";

	if (@mysql_query($sql)) {
	  echo '<p>The database was updated successfully.</p>';
	} else {
	  echo '<p>Error encountered during update: ' . mysql_error() . '</p>';
	}

	if ($showquery) echo "<p>Query used: $sql</p>";
	return;
}

function set_cookie($name, $value, $maxage = NULL, $path = NULL, $domain = NULL, $secure = NULL, $comment = NULL)
{
	// based on rfc2109 cookie specification http://www.faqs.org/rfcs/rfc2109.html
	
	$header = 'Set-Cookie: ' . urlencode($name) . '=' . urlencode($value) . '; Version=1';
	
	if(isset($maxage)) $header .= "; Max-Age=$maxage";
	if(isset($path)) $header .= "; Path=" . urlencode($path);
	if(isset($domain)) $header .= "; Domain=" . urlencode($domain);
	if(isset($secure)) $header .= "; Secure";
	if(isset($comment)) $header .= "; Comment=" . urlencode($comment);
	
	header($header);
}


function redirect($to)
{
	header('Location: ' . $to);
	exit();
}

?>