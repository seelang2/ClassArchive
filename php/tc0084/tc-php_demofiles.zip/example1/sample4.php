<?php

require_once("config.php");

$tablename = "user_info";


if (isset($_GET['mode']) && $_GET['mode'] != "") $mode = strtoupper($_GET['mode']); else $mode = "";

if (isset($_GET['id']) && $_GET['id'] != "") $id = $_GET['id']; else $id = "";


include("header.php"); // include header file

?>

<script type="text/javascript">
function del_confirm() {
	return confirm("Do you really wish to delete this item permanently?");
}
</script>

<?php

switch ($mode)
{
	case 'ADD':
		db_mpform_update("ADD", $tablename);
	break;
	case 'ADDFORM':
		$field_labels = $table_field_labels[$tablename];
		db_mpform("ADD", $tablename, $field_labels, "$me?mode=add");
	break;
	case 'EDIT':
		$idfield = 'id';
		db_mpform_update("EDIT", $tablename, $id, $idfield);
	break;
	case 'EDITFORM':
		$field_labels = $table_field_labels[$tablename];
		db_mpform("EDIT", $tablename, $field_labels, "$me?mode=edit&id=$id", $id);
	break;
	case 'DELETE':
		db_delete($tablename, $id);
	break;
	case 'LIST':
		$field_labels = $table_field_labels[$tablename]; // assign specific table label array (from database.php
		db_list($tablename, $field_labels);
	break;
	default:
?>
<p>Demo: Dynamic forms and submission demo using static table (user_info) and deletion confirmation using JavaScript.</p>
<p>Please select an operation from the menu above.</p>

<?php
	break;
}

include("footer.php"); // include footer file
?>