<?php

require_once("config.php");

$tablename = "user_info";

if (isset($_GET['mode']) && $_GET['mode'] != "") $mode = strtoupper($_GET['mode']); else $mode = "LIST";
if (isset($_GET['id']) && $_GET['id'] != "") $id = $_GET['id']; else $id = "";


include("header2.php"); // include header file

?>
	<div id="submenu">
	<a href="<?php echo $me; ?>?mode=list">List Records</a>&nbsp;|
	<a href="<?php echo $me; ?>?mode=addform">Add New Record</a>&nbsp;
	</div>
	<h2>Manage Users</h2>
<?php

switch ($mode)
{
	case 'ADD':
		db_mpform_update("ADD", $tablename);
	break;
	case 'ADDFORM':
		$field_labels = $table_field_labels[$tablename];
		db_mpform("ADD", $tablename, $field_labels, "$me?mode=add");
	break;
	case 'EDIT':
		$idfield = 'id';
		db_mpform_update("EDIT", $tablename, $id, $idfield);
	break;
	case 'EDITFORM':
		$field_labels = $table_field_labels[$tablename];
		db_mpform("EDIT", $tablename, $field_labels, "$me?mode=edit&id=$id", $id);
	break;
	case 'DELETE':
		db_delete($tablename, $id);
	break;
	case 'LIST':
		$field_labels = $table_field_labels[$tablename]; // assign specific table label array (from database.php
		db_list($tablename, $field_labels);
	break;
	default:
?>
<p>Demo: Modular Reusable (function-based) Code</p>
<p>Using static table (user_info) and deletion confirmation using JavaScript.</p>
<p>Please select an operation from the menu above.</p>

<?php
	break;
}

include("footer.php"); // include footer file
?>