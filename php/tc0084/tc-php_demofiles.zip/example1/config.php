<?php
/*
config.php - Simple config file
*/

$me = $_SERVER['PHP_SELF'];

require_once("database.php");
require_once("functions.php");


?>