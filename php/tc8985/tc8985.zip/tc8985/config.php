<?php
/**
 *	config.php - App settings
 */

// database configuration
@define('DB_HOST', 'localhost');
@define('DB_USER', 'root');
@define('DB_PASSWORD', 'xampp');
@define('DB_NAME', 'tc8985');

