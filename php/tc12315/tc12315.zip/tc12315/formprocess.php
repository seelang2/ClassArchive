<?php

echo '<pre>'.print_r($_GET, true).'</pre>';

echo '<h1>Form Details</h1>';

echo '<p>Name: ' . $_GET['name'] . '</p>';
echo '<p>Status: ' . $_GET['status'] . '</p>';



?>