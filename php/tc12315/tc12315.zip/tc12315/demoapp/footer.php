	</div>

	<div id="pagefooter">
		<p>Creative Commons License 3.0 <?php echo date('Y'); ?>. Free to use, attribution optional.</p>
	</div>
</div><!-- wrpper -->

</body>
</html>