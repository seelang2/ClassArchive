<?php 
require_once "config.php";

// page-specific configuration
$pagetitle = "Demo4 - Basic Page Template";

include "demo4-header.php"; 
?>

		<p>Foo.</p>

<?php include "demo4-footer.php"; ?>