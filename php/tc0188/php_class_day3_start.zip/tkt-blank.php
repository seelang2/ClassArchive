<?php 
require_once "tkt-config.php";

// page-specific configuration
$pagetitle = "Ticket System - Demo";

include TEMPLATE_HEADER; 

?>
<h2>Section Title</h2>
<div id="submenu">
	<a href="#">Link</a> | 
	<a href="#">Link</a>
</div>

	<p>Foo.</p>

<?php include TEMPLATE_FOOTER; ?>