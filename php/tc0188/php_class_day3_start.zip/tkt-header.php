<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="tkt-stylesheet.css" media="all" />

<title><?php echo $pagetitle; ?></title>

</head>
<body>

<div id="wrapper">
	<div id="header">
		<h1>Ticket Support System Demo</h1>
		<div class="menu">
			<a href="tkt-main.php">Main</a> |
			<a href="tkt-users.php">Manage users</a> |
			<a href="tkt-types.php">Manage Types</a>
		</div>
	</div>
	<div id="content">
