<?php

echo "<br><br>";
echo phpinfo();

?>
