<?php

require_once('config.php');

include('header.php');

?>




<?php include('footer.php'); ?>