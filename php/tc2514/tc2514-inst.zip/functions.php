<?php
/*
	functions.php - function library
*/


function escape($string) {
	return mysql_real_escape_string($string);
}



