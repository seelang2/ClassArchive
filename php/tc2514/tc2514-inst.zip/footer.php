    
    </div>
    <div id="footer">
    	<span>Copyright &copy; <?php echo date('Y'); ?>Training Connection Class 2514. Some Rights Reserved.</span>
    </div><!-- footer -->

</div><!-- wrapper -->



</body>
</html>