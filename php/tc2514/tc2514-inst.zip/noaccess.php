<?php

require_once('config.php');

include('header.php');

?>

<h1>No Soup For You!</h1>

<p>You do not have authorization to view the requested page.</p>

<p>*snap*</p>

<?php include('footer.php'); ?>