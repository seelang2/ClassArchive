<?php 
require_once('init.php'); 
require('header.php');
?>

<h1>Forbidden</h1>
<p>You do not have access to the requested resource.</p>

<?php require('footer.php'); ?>