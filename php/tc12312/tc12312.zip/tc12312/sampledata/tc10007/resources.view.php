<h1>Resources Detail View</h1>
