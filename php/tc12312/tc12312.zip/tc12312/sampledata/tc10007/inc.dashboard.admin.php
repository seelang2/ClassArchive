

<p><a href="?controller=users&action=list">Manage Users</a></p>
<p><a href="#">Manage Clients</a></p>
<p><a href="?controller=resources&action=list">Manage Resources</a></p>
<p><a href="#">Manage Reports</a></p>
<p><a href="#">Update Pricing</a></p>
