<p>this is whatever you want.</p>
<p>And it's just plain HTML (unless you put PHPin here.)</p>