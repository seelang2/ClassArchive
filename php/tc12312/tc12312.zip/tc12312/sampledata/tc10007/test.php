<?php

//echo basename($_SERVER['PHP_SELF']);

//$list = array(1, 3, 4, 6, 12, 22);
//$query = "select * from resources where id in (". implode(',',$list) .")";
//echo $query;

echo sha1(microtime());
echo '<br />';
echo sha1('obvious'.'b77939e05ba858b3f74d9b90fae620ec7a045834');
