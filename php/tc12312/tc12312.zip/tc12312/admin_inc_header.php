<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Admin Application</title>

	<link type="text/css" rel="stylesheet" href="style.css" />
	<style type="text/css">
	</style>
</head>
<body>

<div id="wrapper">
	<header id="masthead">
		<div style="text-align:right;">
			<a style="color:#ffffff;text-decoration:none;" href="?logout=1">Log out</a>
		</div>
	</header>
	<div id="content">
