<?php
/**
 * Configuration parameters
 */

// database
@define('DB_HOSTNAME', 'localhost');
@define('DB_NAME', 'tc12312');
@define('DB_USER', 'root');
@define('DB_PASSWORD', '');

// security
// Take note: https://crackstation.net/hashing-security.htm
@define('PASSWORD_SALT', '34o5buj2o4ucib3t');

@define('ERROR_GENERAL', 'general_error.html');
@define('LOGFILE', 'log.txt');

