<?php
/**
 * Application startup/initialization
 */

require_once('inc-config.php');
require_once('inc-functions.php');
require_once('inc-database.php');

// enable sessions
session_start();

