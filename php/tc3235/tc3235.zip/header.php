<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Untitled Document</title>

<style type="text/css">
body {
	font-family:Verdana, Geneva, sans-serif;
	font-size: 85%;
	color :#000;
	background: #dedede;
}

#wrapper {
	margin: 0 auto;
	padding: 0;
	width: 800px;
	background: #fff;
}

#header, #footer {
	background: #006;
	color: #fff;
	height: 80px;
	overflow: hidden;
}

#footer {
	height: 40px;
	font-size: 80%;
}

</style>

</head>

<body>

<div id="wrapper">
	<div id="header">Demo Application</div>
    <div id="content">
    
