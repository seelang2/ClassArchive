    
    </div><!-- content -->
    <div id="footer">
    	<span>Copyright &copy <?php echo date('Y'); ?>.</span>
    </div>
</div><!-- wrapper -->

</body>
</html>