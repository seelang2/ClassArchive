<?php

$dbcnx = mysql_connect('localhost','root','test');
if (!$dbcnx) exit('Error connecting to database server.');

?>