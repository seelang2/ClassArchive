    </div>
    
    <div id="footer">
    	<span>Copyright &copy; <?php echo date('Y'); ?> TC Class 2278. Some rights reserved.</span>
    </div><!-- footer -->

</div><!-- wrapper -->


</body>
</html>