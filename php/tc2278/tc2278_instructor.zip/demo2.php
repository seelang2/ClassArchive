<?php

echo '<p>Welcome, ' . $_GET['firstname'] . ' ' . $_GET['lastname'] . '!</p>';


?>