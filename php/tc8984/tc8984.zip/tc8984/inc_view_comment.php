<tr class="comment">
	<td>
		<?php echo $comment['comment_date']; ?>
	</td>
	<td>
		<?php echo $comment['author']; ?>
	</td>
	<td>
		<?php echo $comment['comment']; ?>
	</dt>
</tr>