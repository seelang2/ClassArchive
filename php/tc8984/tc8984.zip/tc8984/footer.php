	</div><!-- content -->

	<div id="footer">
		<p>TC Class 8984. Creative Commons License.</p>
	</div><!-- footer -->
</div><!-- wrapper -->

</body>
</html>