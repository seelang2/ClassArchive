<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page title</title>

</head>
<body>

</body>
</html>