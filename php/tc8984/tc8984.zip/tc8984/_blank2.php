<?php
require('init.php');


include('header.php');


include('footer.php');
?>