<?php include('header.php'); ?>

		<p><a href="manage.php?table=facilities&action=list">Manage Facilities</a></p>
		<p><a href="manage.php?table=users&action=list">Manage Users</a></p>

<?php include('footer.php'); ?>