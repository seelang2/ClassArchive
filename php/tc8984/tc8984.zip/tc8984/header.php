<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page title</title>

	<link href="style.css" type="text/css" rel="stylesheet" />

</head>
<body>

<div id="wrapper">
	<div id="masthead">
		<h1>Demo App</h1>
	</div>

	<nav id="topnav">
		<a href="start.php">Home</a> | 
		<a href="ticket.php?&action=list">Tickets</a> | 
		<a href="manage.php?table=facilities&action=list">Facilities</a> | 
		<a href="manage.php?table=users&action=list">Manage Users</a>
	</nav>

	<div id="content">
