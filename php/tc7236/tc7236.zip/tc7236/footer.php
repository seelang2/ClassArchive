	</div><!-- content -->
	
	<footer>
		<span>Copyright &copy; <?php echo date('Y'); ?> TC Class 7236. Creative Commons License.</span>
	</footer>
</div><!-- wrapper -->


</body>
</html>	