<?php
// clitest.php - command line executable script

echo "This space for rent.\n";
echo "Seems to be working.\n";

