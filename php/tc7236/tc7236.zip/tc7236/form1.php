<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page Title</title>
	
	<style type="text/css"></style>
</head>
<body>

<form action="process1.php" method="get">
	<input type="hidden" name="action" value="process" />
	<div>
		<label>First Name: <input name="firstname" /></label>
	</div>

	<div>
		<label>Last Name: <input name="lastname" /></label>
	</div>

	<div><input type="submit" /></div>
</form>

</body>
</html>	