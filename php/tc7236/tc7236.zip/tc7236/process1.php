<?php
	// process1.php

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Process Prage</title>
	
	<style type="text/css"></style>
</head>
<body>

<h1>Welcome!</h1>
<p>Glad you could make it, <?php echo $_GET['firstname']. ' ' .$_GET['lastname']; ?>!</p>

</body>
</html>	
