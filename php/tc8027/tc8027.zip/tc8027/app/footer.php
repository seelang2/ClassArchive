	</div><!-- content -->
	<footer>
		<span>Copyright &copy;<?php echo date('Y'); ?> TC Class 8027. Creative Commons License</span>
	</footer>
</div><!-- wrapper -->
<body>
</html>

