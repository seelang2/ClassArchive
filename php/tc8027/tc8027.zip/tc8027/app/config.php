<?php

// app parameters
define('DB_NAME','tc8027');
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','xampp');

define('DB_ERROR_LOG','sql_error.log');

