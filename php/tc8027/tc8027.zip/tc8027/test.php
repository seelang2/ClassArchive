<?php

phpinfo();

