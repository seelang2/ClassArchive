<!doctype html>
<html>
<head>
	<title><?php ?></title>

</head>
<body>

<?php

echo '<p>This space for rent.</p>';



?>


</body>
</html>