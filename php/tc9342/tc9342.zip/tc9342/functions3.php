<?php

function doStuff($message) {
	return '<p>'. $message .'</p>'; 
}

echo doStuff('This is a message.');


