<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page Title</title>

	<style type="text/css">
	</style>
</head>
<body>

<form action="process.php" method="post">
	<label>
		<span>First Name:</span>
		<input type="text" name="firstname" />
	</label>
	<label>
		<span>Last Name:</span>
		<input type="text" name="lastname" />
	</label>
	<div><input type="submit" /></div>
</form>

</body>
</html>