<?php

// do some processing

// redirect to another page
header('Location: landingpage.php');
exit(); // ALWAYS exit after redirect

// this stuff is safe
