<?php 


require('config.php');
require('database.php');
