<?php

// define constants for app

// database settings
define('DB_NAME', 'tc9342');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWD', 'xampp');

