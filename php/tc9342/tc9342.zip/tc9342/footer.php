	</div><!-- content -->

	<div id="pagefooter">
		<p>Creative Commons <?php echo date('Y'); ?> 
			Training Connection class 9342. Free for use.</p>
	</div>

</body>
</html>