<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page Title</title>

	<style type="text/css">
	</style>
</head>
<body>

<form action="interests-add.php" method="post">
	<label>
		<span>Interest Name:</span>
		<input type="text" name="name" />
	</label>
	<div><input type="submit" /></div>
</form>

</body>
</html>