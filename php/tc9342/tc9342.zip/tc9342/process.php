<?php

//echo '<pre>'.print_r($_GET, true).'</pre>';

echo '<h1>Welcome '. 
	 $_POST['firstname'] . ' ' . 
	 $_POST['lastname'] . '!</h1>';

