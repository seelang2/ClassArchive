	</section>
	<footer>
		<p>Copyright &copy; <?php echo date('Y'); ?></p>
	</footer>
</div>

</body>
</html>