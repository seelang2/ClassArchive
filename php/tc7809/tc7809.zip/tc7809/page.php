<?php

include('header.php');
?>
	
	<p>This space for rent.
	
<?php
include('footer.php');
?>