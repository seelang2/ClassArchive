<!-- WPDM Link Template: Link Template Embedded -->
<style>.pull-left:hover,.pull-left:hover span{text-decoration: none;} .wpdm-slock{ float:left; margin-right:5px; } .wpdm-pro form{ margin-bottom:0px;} .wpdm-pro .thumbnail strong{ font-size:8pt; }</style>
<div class="media thumbnail">
    <div class="pull-left"><a href="[page_url]">
    [thumb_150x150]</a><br>
    <span style="color: #444;text-decoration: none;font-size:8pt;margin-top: 10px;">
    <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-th-large"></i> [file_size] <br/>
    <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-download-alt"></i> [download_count] downloads
    </span>
    </div>
    <div class="media-body" style="padding-left: 5px;">
    <h4 class="media-heading" style="padding-top: 0px;border:0px;margin: 0px;">[page_link]</h4>    
    <div class="row-fluid">
    [download_link_extended]     
    </div>
    </div>
</div>
