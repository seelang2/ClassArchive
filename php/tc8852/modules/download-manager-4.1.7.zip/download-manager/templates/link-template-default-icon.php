<!-- WPDM Link Template: Default Template w/Icon -->
<div class="media">
    <a class="pull-left" href="[page_url]">
    [icon]
    </a>
    <div class="media-body">
    <h4 class="media-heading" style="padding-top: 0px;border:0px;margin: 0px;">[page_link]</h4>
    [download_link] <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-download-alt"></i> [download_count] downloads
    </div>
</div>