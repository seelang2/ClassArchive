<!-- WPDM Link Template: Metro Style -->
 
<div class="metro-block span4 wpdm-metro" style="margin: 0 5px 7px 0;">
    <a href="[page_url]">
    [thumb_500x300]
    </a>
    <div class="caption">
    <h4 class="media-heading" style="padding: 0px;margin:0px">[page_link]</h4>
    <p>
    [file_size] | [download_count] downloads 
    </p> 
    <div class="btn-group">
    <a href="[page_url]" class="btn btn-inverse">Details</a>[download_link]
    </div>
    </div>
</div> 
 