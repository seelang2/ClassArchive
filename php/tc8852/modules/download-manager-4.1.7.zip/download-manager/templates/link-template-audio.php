<!-- WPDM Link Template: With MP3 Preview -->
<div class="w3eden">
<div class="media thumbnail">
    <div class="pull-left">
    [icon]
    </div> 
    <div class="media-body">
    <h4 class="media-heading">[page_link]</h4>
        [audio_player_single]
    <div class="btn-small" style="padding-left: 0px;">
    <i style="margin: 2px 0 0 0px;opacity:0.5" class="icon icon-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-download-alt"></i> [download_count] downloads
    </div>
    </div>
</div>
</div>