<!-- WPDM Link Template: Default Template -->
<div class="col-md-6">
<div class="thumbnail">
<div class="media">
    <a class="pull-left" href="[page_url]">
    [thumb_60x60]
    </a>
    <div class="media-body">
    <h4 class="media-heading" style="padding-top: 0px;border:0px;margin: 0px;">[page_link]</h4>    
    [download_link] <i style="margin: 2px 0 0 5px;opacity:0.5" class="fa fa-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="fa fa-download-alt"></i> [download_count] downloads
    </div>
</div>
</div>
</div>