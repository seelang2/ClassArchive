<!-- WPDM Template: 2 Columns, Image Right -->
<div class="row">
<div class="col-md-7">      
[description]  
<br /> 
[file_list] 
[audio_player]<br>
</div>
<div class="col-md-5">
<img src="[thumb_url_600x450]" class="img-rounded">
<table class="table">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Stock</td><td>[quota]</td></tr>
<tr><td>Total Files</td><td>[file_count]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td>
</tr>
</tbody></table>
<div class="wpdm-download-button">
[download_link_extended]   <br>

</div>
</div> 
</div>


