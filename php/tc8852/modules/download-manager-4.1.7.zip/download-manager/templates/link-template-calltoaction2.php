<!-- WPDM Link Template: Call to Action 2 -->
<blockquote class="light left">
<div class="row-fluid">
<div class="span12">
    <div class="pull-right" align="right">
        [download_link]
    </div>
<div class="media">
    <div class="media-body">
    <h3 class="media-heading" style="padding-top: 0px;border:0px;margin: 0px;">[page_link] <span style="margin-left:30px;font-size:8pt;font-weight:300"><i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="icon icon-download-alt"></i> [download_count] downloads</span></h3>    
    [excerpt_80]
    </div>

</div>
</div>
</div>
</blockquote>