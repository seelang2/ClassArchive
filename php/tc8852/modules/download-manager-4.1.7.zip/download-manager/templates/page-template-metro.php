<!-- WPDM Template: Metro Style -->
<div class="row-fluid wpdm-metro">
<div class="col-md-7">
[description]

<br />      
[file_list]   
 
</div>
<div class="col-md-5 metro-block">
<img src="[thumb_url_600x450]">
<table class="table">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Stock</td><td>[quota]</td></tr>
<tr><td>Total Files</td><td>[file_count]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td>
</tr>
</tbody></table>
<div class="wpdm-download-button">
[download_link]

</div>
</div> 
</div>


