<?php

$msgs = array(

                'DOWNLOAD_LIMIT_EXCEED' => 'Download Limit Exceeded',
                'PASSWORD_LIMIT_EXCEED' => 'Password usages limit exceeded',
                'ENTER_PASSWORD' => 'Password'
);

?>