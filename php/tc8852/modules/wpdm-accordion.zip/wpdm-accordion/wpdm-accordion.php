<?php
/*
Plugin Name: WPDM - Accordion
Description: Display everything in a accordion
Plugin URI: http://www.wpdownloadmanager.com/
Author: Shaon
Version: 1.5.0
Author URI: http://www.wpdownloadmanager.com/
*/

function wpdmac_data(){
    global $wpdb;
    if(isset($_GET['wpdmactask']) && $_GET['wpdmactask']=='listsub'){
        $cats = maybe_unserialize(get_option('_fm_categories'));
        $parent = isset($_GET['parent'])?$_GET['parent']:"";
        $cats = get_terms('wpdmcategory', array('hide_empty' => false, 'parent' => $parent));
        $packs = new WP_Query(array("post_type" => "wpdmpro","posts_per_page"=>999999, 'tax_query' => array(array('taxonomy'=>'wpdmcategory', 'terms'=>array($parent),'field'=> 'id' ))));

        //$packs = $wpdb->get_results("select * from {$wpdb->prefix}ahm_files where category like '%\"$_GET[parent]\"%'", ARRAY_A);
		//echo ('<pre>');print_r($cats);echo ('</pre>');
		//echo ('<pre>');print_r($_GET[parent]);echo ('</pre>');
		//echo ('<pre>');print_r($packs);echo ('</pre>');
        if(isset($_GET['showsub']) && $_GET['showsub']==1){
      ?>

        <div id="accordion-<?php echo $parent ?>" class="panel-group">
		<?php foreach($cats as $cat): if($cat->parent==$parent): ?>
            <div class="panel panel-default"><div class="panel-heading">
            <a data-toggle="collapse" data-parent="#accordion-<?php echo $cat->parent; ?>" href="#z<?php echo $cat->term_id; ?>" rel="<?php echo $cat->term_id; ?>"><?php echo $cat->name; ?></a></div>
            <div id="z<?php echo $cat->term_id; ?>" class="panel-collapse collapse">
            <div class="panel-body">
                <div id="<?php echo $cat->term_id; ?>"><i class="fa fa-spinner fa-spin"></i> Loading...</div>
            </div>
            </div>
            </div>
        <?php endif; endforeach; ?>
	    </div>
    <?php } ?>
	<ul class="list-group" style="padding: 0 !important;">
		<?php while($packs->have_posts()): $packs->the_post();
			$icon = get_post_meta(get_the_ID(), '__wpdm_icon', true);
            $icon = $icon!=""?$icon:'_blank.png';
			$icon = plugins_url('wpdm-accordion/assets/icons/'.$icon);
            $exts = wpdm_package_filetypes(get_the_ID(), false);
            $ext = count($exts)>1?'zip':@$exts[0];

		?>
        <li  class="list-group-item" style="padding: 10px 10px 15px 10px">
            <div class="pull-left" style="margin-right: 10px;width:48px;ehgith:50px">
                <?php the_post_thumbnail( 'thumbnail', array('class'=>'img-rounded acc-thumb') ); ?>
            </div>
            <div class="pull-right">
                <a class="btn btn-lg btn-default" style="box-shadow: none !important" href="<?php the_permalink();?>"><i class="icon icon-chevron-right"></i></a>
                <?php //echo str_replace("[btnclass]", $ext,wpdm_get_download_link(get_the_ID())); ?>
            </div>
            <div class="media-body">
                <h3 style="margin: 0;font-weight:700;line-height:25px;font-size:12pt"><a style="font-weight:700;" href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
                <small><i class="fa fa-calendar"></i> <?php echo get_the_date(); ?></small>
            </div>
        </li>

		<?php endwhile; ?>
	</ul>
	<?php 
		die(); 
	}
} 
 
function wpdm_accordion($params = array()){
    $opts = array('hide_empty' => false, 'parent' => 0,'hierarchical'=>1);
    if(isset($params['cats'])){
        $opts['include'] = explode(",", $params['cats']);
        $opts['hierarchical'] = 0;
        unset($opts['parent']);
    }

    $cats = get_terms('wpdmcategory', $opts);

    ob_start();
    ?>
    <script type="text/javascript">
        jQuery(function($) {
    $('#accordion').on('show.bs.collapse', function (e) {
        if(jQuery(e.target).attr('data-status')!='loaded')
        jQuery(e.target).find('.panel-body').load("<?php echo home_url('/');?>?wpdmactask=listsub&showsub=<?php echo $opts['hierarchical'];?>&parent="+jQuery(e.target).attr('id').replace('z','')).attr('data-status','loaded');
    });
        });
    </script>
	<!--script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('wpdm-accordion/assets/style.css'); ?>" />
    
<script type="text/javascript">
jQuery(function() {
    jQuery(".wpdm-accordion").accordion({
        collapsible: true, 
        autoHeight: false, 
        active: false
    });
    jQuery('.mainTitle').click(function(){
	console.log('parent function start');
        jQuery('.packs').removeAttr('class');
        jQuery(jQuery(this).find('a').attr('href')).load('?wpdmactask=listsub&parent='+jQuery(this).find('a').attr('rel'),function(){
            jQuery('.packs').removeClass('ui-accordion-header ui-helper-reset ui-state-default ui-corner-all');
             jQuery(".wpdm-accordion").accordion({
				collapsible: true, 
				autoHeight: false, 
				active: false
			}); 
              jQuery('div.ui-accordion-header').removeClass('ui-accordion-header ui-helper-reset ui-state-active ui-corner-top').addClass('ui-accordion-content');
        });
    });  
});
function wpdmac_data(a){
a = jQuery(a).find('a');
console.log('sub function start:'+ a);
        if(!jQuery(this).hasClass('ac-active')){
        jQuery(jQuery(a).attr('href')).load('?wpdmactask=listsub&parent='+jQuery(a).attr('rel'),function(){
              jQuery(".wpdm-accordion").accordion({
                                                collapsible: true, 
                                                autoHeight: false, 
                                                active: false
                                            }); 
              jQuery('div.ui-accordion-header').removeClass('ui-accordion-header ui-helper-reset ui-state-active ui-corner-top').addClass('ui-accordion-content');
        });
            jQuery(this).addClass('ac-active');
        } else {
            jQuery(this).removeClass('ac-active');
        }
    }
</script -->

	<div id="accordion-groups" class="w3eden">
	<div id="accordion" class="panel-group">
		<?php foreach($cats as $cat): if($cat->parent==0||$opts['hierarchical']==0): ?>
            <div class="panel panel-default"><div class="panel-heading">
			<a data-toggle="collapse" data-parent="#accordion" href="#z<?php echo $cat->term_id; ?>" rel="<?php echo $cat->term_id; ?>"><?php echo $cat->name; ?></a></div>
                <div id="z<?php echo $cat->term_id; ?>" class="panel-collapse collapse">
            <div class="panel-body">
			<div id="<?php echo $cat->term_id; ?>"><i class="fa fa-spinner fa-spin"></i> Loading...</div>
            </div>
            </div>
            </div>

		<?php endif; endforeach; ?>
	</div>
	</div>
    <style>
        #accordion-groups .panel{
            border: 1px solid #dddddd !important;

        }
        img.acc-thumb{
            max-width: 48px;
            height: auto !important;
            margin-right: 10px;
            border-radius: 3px !important;
        }
        ul.list-group li{
            margin-left: 0 !important;
        }
        ul.list-group{
            margin: 0 !important;
            padding: 0 !important;
        }
        .panel-default .panel-default>.panel-heading{background-image:-webkit-gradient(linear,left 0,left 100%,from(#FBFBFB),to(#F6F6F6));background-image:-webkit-linear-gradient(top,#FBFBFB 0,#F6F6F6 100%);background-image:-moz-linear-gradient(top,#FBFBFB 0,#F6F6F6 100%);background-image:linear-gradient(to bottom,#FBFBFB 0,#F6F6F6 100%);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffFBFBFB',endColorstr='#ffF6F6F6',GradientType=0); }
    </style>
    <?php

    $data = ob_get_clean();
    return $data;
} 

add_shortcode('wpdm-accordion','wpdm_accordion');
add_action('init','wpdmac_data');
 

