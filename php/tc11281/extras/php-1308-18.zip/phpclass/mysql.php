<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
<style type="text/css">
table td {
	background-color: #F3F3F3;
	border: medium none;
	padding: 10px;
	text-align: center;
}
</style>
</head>

<body>
<table>
	<tr>
        <td><strong>ID</strong></td>
        <td><strong>First Name</strong></td>
        <td><strong>Last Name</strong></td>
        <td><strong>Email</strong></td>
    </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
</table>

</body>
</html>