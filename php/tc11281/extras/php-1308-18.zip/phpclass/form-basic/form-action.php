<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>A Simple Form</title>
</head>

<body>
<p><strong>Name:</strong></p>
<p><strong>Email:</strong></p>
<p><strong>Level:</strong></p>
<p><strong>Publications:</strong></p>
<p><strong>How often track:</strong></p>
<p><strong>Comments:</strong></p>
</body>
</html>