<div id="footer">Copyright The Fronion - All Rights Reserved
    <div id="footerLeftCorner"></div>
    <div id="footerRightCorner"></div>
</div>