<?php
/**
 * functions.php - include library
 */

// debugging function
function dumpvar($data) {
	return '<pre>'.print_r($data, true).'</pre>';
}



