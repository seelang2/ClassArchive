<?php require('startup.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>the Fronion - News That Doesn't Stink</title>
<link href="styles-main.css" rel="stylesheet" type="text/css">
<!--[if lte IE 6]>

<link href="styles-ie6.css" rel="stylesheet" type="text/css">


<![endif]-->
</head>
<body>
<div id="contentWrapper">
  <?php require_once('inc/header.php'); ?>
  <?php require_once('inc/nav.php'); ?>
  <div id="mainContent">
    <h1>Entertainers Support Sporks</h1>
    <h2>Celebs Spork Over The Cash at Charity Fundraisers</h2>
    <p><img src="img/hollywood.jpg" width="220" height="165" class="picLeft">Hollywood, CA: Celebrities are coming out in droves to support the use of sporks. This shift is based on recent public reports of how environmentally friendly sporks are (they
      replace both spoons and forks so consume less materials and take less energy to clean). Some question though if celebrities are honestly trying to be good stewards of the environment, or if they just looking to get free press. Even though they may
      be exploiting this issue to get us to write about them, we still did it because it could benefit Mother Earth. Just think of all the obsessed fans that will use sporks just because Paris Hilton does!</p>
    <h1>Michael Bolton and Kenny G in Bar Fight</h1>
    <h2>No Synthesizers Were Harmed In The Incident</h2>
    <p>Beverly Hills, CA: In an escalation of their 20-year feud, smooth jazz musicians Michael Bolton and Kenny G came to blows yesterday. While it is not known what sparked the confrontation, witnesses allegedly heard Kenny G shout, &quot;Now who's smooth?&quot; as he crashed a bar stool over Bolton's head. Waitresses claim that the pair was very drunk and, though they had not been sitting together, had both been drinking watermelon martinis. Police did not arrest either entertainer, stating that, &quot;The wedgies were well deserved.&quot;</p>
  </div>
  <?php require_once('inc/sidebar.php'); ?>
  <?php require_once('inc/footer.php'); ?>
</div>
</body>
</html>
