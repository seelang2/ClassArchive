<div id="sidebar">
    <h1>Submission Guidelines:</h1>
    <p>Anonymity:  Feel free to omit your contact information for any story. We will act on the tip regardless of source. However if we cannot verify the story with other information, we may not be able to publish it.</p>
    <p>Credit: If you tip us off to a new story we will give you credit in the article (assuming you provide your name). Your email address will never be published.</p>
    <p>Rights: We reserve all rights to the information and stories you provide. By submitting a story, you are giving us permission to publish it without financial or other forms or compensation.</p>
    <p>Thank you for your tips!</p>
</div>