<div id="sidebar">
    <h1>Got a Story to Share?</h1>
    <p>Our reporters can't be everywhere at exactly the right time. If you see something newsworthy we'd love to hear about it.</p>
    <p><a href="report-story.php">Report a News Story Now</a></p>
    <div id="twitter"><img src="img/twitter.png" width="96" height="38"></div>
</div>