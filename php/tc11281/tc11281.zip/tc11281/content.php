<?php include('header.php'); ?>
<!-- content start -->

<p>Page content.</p>

<!-- content end -->
<?php include('footer.php'); ?>