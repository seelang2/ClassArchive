<?php


function output($string = '&nbsp;', $element = 'p') {
	echo '<'.$element.'>'.$string.'</'.$element.'>';
}

