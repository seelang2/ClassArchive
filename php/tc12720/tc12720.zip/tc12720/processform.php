<?php

echo '<h2>$_GET:</h2>';
echo '<pre>'.print_r($_GET, true).'</pre>';

echo '<h2>$_POST:</h2>';
echo '<pre>'.print_r($_POST, true).'</pre>';

echo '<h2>$_REQUEST:</h2>';
echo '<pre>'.print_r($_REQUEST, true).'</pre>';


?>