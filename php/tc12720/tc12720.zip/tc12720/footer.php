		<!-- end content -->
	</div><!-- #content -->
	<footer id="pagefooter">
		<p>Copyright &copy; <?php echo date('Y'); ?> Creative Commons License. Use at your own risk.</p>
	</footer>
</div><!-- #wrapper -->

</body>
</html>