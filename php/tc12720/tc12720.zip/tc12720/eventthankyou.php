<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Error</title>

	<style type="text/css">
	</style>
</head>
<body>

<h1>Registration Confirmed</h1>

<p>Thank you for registering, yadda yadda yadda...</p>


</body>
</html>