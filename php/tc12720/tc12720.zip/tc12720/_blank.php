<!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>Page Demo</title>

	<style type="text/css">
	</style>
</head>
<body>

<?php

echo '<p>This space for rent.</p>';

?>



</body>
</html>