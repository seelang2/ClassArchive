<?php
/**
 * App configuration settings
 */

// database settings
@define('DB_HOST', 'localhost');
@define('DB_NAME', 'tc12720');
@define('DB_USER', 'adminer');
@define('DB_PASSWORD', 'a9e.1FD13!');

// other config settings..


